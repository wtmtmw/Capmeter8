# Capmeter8
:warning: This project is still a work in progress

Python implementation of algorithms and software published by [Wang and Hilgemann (2008)](https://doi.org/10.1085/jgp.200709950).

MATLAB version of the software is provided in the publication above and [here](https://sites.google.com/site/capmeter/home).